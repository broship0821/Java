package final_.field;

public class Person {
	
	final String nation = "대한민국";
	final String name;
	int age;
	
	public Person(String name) {
		this.name = name;
	}

}
