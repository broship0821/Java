package inter.basic;

public interface Inter {
	
	void testMethod();

}
