package abs.bad;

public class Store extends HeadStore {

	public void orderApple() {
		System.out.println("사과쥬스의 가격은 3000원 입니다.");
	}
	
	public void orderBANANA() {
		System.out.println("바나나쥬스의 가격은 2800원 입니다.");
	}
	
	public void grapeOrder() {
		System.out.println("포도쥬스의 가격은 3200원 입니다.");
	}
	
	
	
	
	
	
	
	
	
	
}
