
public class RSP {

	public static void main(String[] args) {
		
		//문자열로 이루어진 정수를 실제 정수로 변환하는 방법.
		//Integer.parseInt(문자열 or 문자열이 들어있는 변수)
		String s1 = "10";
		String s2 = "34";
		System.out.println(s1 + s2);
		
		int i1 = Integer.parseInt(s1);
		int i2 = Integer.parseInt(s2);
		System.out.println(i1 + i2);
		
		
		
		
		
		
		
		
		

	}

}
