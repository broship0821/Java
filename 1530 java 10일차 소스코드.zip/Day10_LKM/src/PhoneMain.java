
public class PhoneMain {

	public static void main(String[] args) {
		
		Phone basic = new Phone();
		basic.showSpec();
		
		Phone galaxyS20 = new Phone("갤럭시s20");
		galaxyS20.showSpec();
		
		Phone iPhone11 = new Phone("아이폰11", "화이트");
		iPhone11.showSpec();
		
		
		
		
		
		
		
		

	}

}
