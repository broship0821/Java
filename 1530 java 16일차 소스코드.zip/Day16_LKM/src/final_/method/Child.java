package final_.method;

public class Child extends Parent {

	@Override
	void method1() {
		// TODO Auto-generated method stub
		super.method1();
	}

	@Override
	void method2() {
		// TODO Auto-generated method stub
		super.method2();
	}
	
	
//	public void method3() {
//		System.out.println("메서드 재정의!");
//	} // final 메서드는 오버라이딩(메서드 재 정의)을 막습니다.
	
	
	
	
	
	
	
	
	
	
	
	

}
