package inter.basic;

public interface Inter2 extends Inter {
	
	void method2(); //public abstract

}
