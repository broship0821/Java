package inter.basic;

public class ImplClass3 implements Inter2 {

	@Override
	public void testMethod() {
		System.out.println("테스트 메서드 구현!");
	}

	@Override
	public void method2() {
		System.out.println("method2 구현!");
	}

}
